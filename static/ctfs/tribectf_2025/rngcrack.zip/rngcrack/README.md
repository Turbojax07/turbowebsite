Thomas Jefferson is communicating with founding fathers Langdon, Carroll, and
Gilman using their so-called "LCG"-based encrypted messaging system.  The
cryptosystem consists of a pseudo-random number generator that produces
integers `x_1, x_2, x_3, ...` Let `m_i` be the `i`th message.  To encrypt
`m_i`, the founding fathers pass the string version of `m_i` to SHA-256,
producing an AES-256 key, `k_i`.  The founders than use AES-256 in CTR mode
to encrypt `m_i` with `k_i`.

For instance, if `x_i` is 13374567, then, `k_i` is the SHA256 of the eight
bytes "13374567".

British spies have captured the first 1000 numbers of the pseudo-random number
generator (`stream.dat`), along with the a message (`ciphertext.bin`) encrypted
with its next random number (the 1001st).  Your goal is to determine the value
of this 1001st random number and decrypt the message.
